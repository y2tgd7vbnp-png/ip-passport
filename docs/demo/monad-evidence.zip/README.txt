IP Passport 证据包 / Evidence package
=====================================
本包只包含目标版本路径（不含其他作品/版本）。
验证方式：打开 Web 验证页拖入本 zip，浏览器本地重算哈希，不上传任何文件。
Verify: open the /verify page and drop this zip — hashes are recomputed locally in your browser; nothing is uploaded.

workId: 0x01b7a4663cb10deca0ab29231fbd52c1522f4893fbf55138f46911fdd530ddc9
目标版本: 0xdea86ef9aaa2f9f5ac84263024ba10bb6d330a7c3b450d7e094c54823e3b862d